# File: src/dashboard/app.py
# Midnight Cyber-Aurora Streamlit Dashboard for GreenAI Email Classifier
# Includes:
# 1. Midnight Cyber-Aurora Glassmorphism CSS Theme
# 2. 📧 Live Gmail Inbox Integration (IMAP Sync & Instant Demo Inbox)
# 3. ⚡ Carbon Impact & Cloud Cost Simulator
# 4. 🔬 AI Keyword Attention & Eco Escalation Decision Log

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import time
import re
from datetime import datetime, timedelta
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.config import Config

# Optional DB imports (safe fallback)
try:
    from src.database import (
        SessionLocal,
        InferenceLog,
        get_model_statistics,
        calculate_energy_savings,
    )
    DB_AVAILABLE = True
except Exception:
    DB_AVAILABLE = False


# -------------------------------------------------------------
# Page Config & Branding
# -------------------------------------------------------------
st.set_page_config(
    page_title="GreenAI — Cyber Eco Classifier",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -------------------------------------------------------------
# Custom CSS — Midnight Cyber-Aurora Glassmorphism Theme
# -------------------------------------------------------------
st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;700&display=swap');

:root {
    --bg-abyss: #060913;
    --card-bg: rgba(13, 19, 36, 0.75);
    --card-border: rgba(139, 92, 246, 0.18);
    --neon-green: #10b981;
    --neon-mint: #34d399;
    --neon-cyan: #38bdf8;
    --neon-violet: #8b5cf6;
    --neon-purple: #a78bfa;
    --neon-amber: #fbbf24;
    --text-primary: #f8fafc;
    --text-secondary: #94a3b8;
}

html, body, [data-testid="stAppViewContainer"] {
    background-color: var(--bg-abyss) !important;
    background-image: 
        radial-gradient(ellipse 80% 50% at 50% -20%, rgba(16, 185, 129, 0.12), transparent 70%),
        radial-gradient(ellipse 60% 40% at 85% 90%, rgba(139, 92, 246, 0.12), transparent 70%),
        radial-gradient(ellipse 50% 30% at 15% 70%, rgba(56, 189, 248, 0.08), transparent 70%);
    font-family: 'Plus Jakarta Sans', sans-serif;
    color: var(--text-primary);
}

[data-testid="stSidebar"] {
    background: rgba(10, 15, 29, 0.92) !important;
    border-right: 1px solid rgba(139, 92, 246, 0.15) !important;
    backdrop-filter: blur(20px);
}

/* Hero Header */
.hero-title {
    font-family: 'Space Grotesk', sans-serif;
    background: linear-gradient(135deg, #10b981 0%, #38bdf8 45%, #a78bfa 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 2.85rem;
    font-weight: 700;
    margin-bottom: 0.15rem;
    letter-spacing: -0.03em;
}

.hero-sub {
    color: #94a3b8;
    font-size: 1.05rem;
    margin-bottom: 1.5rem;
}

/* Glassmorphic Container */
.glass-box {
    background: linear-gradient(135deg, rgba(15, 23, 42, 0.7) 0%, rgba(11, 17, 33, 0.8) 100%);
    border: 1px solid rgba(139, 92, 246, 0.18);
    border-radius: 1.1rem;
    padding: 1.35rem 1.6rem;
    backdrop-filter: blur(20px);
    box-shadow: 0 12px 30px -10px rgba(0, 0, 0, 0.5), 0 0 20px -5px rgba(139, 92, 246, 0.08);
    margin-bottom: 1.35rem;
    transition: all 0.3s ease;
}

.glass-box:hover {
    border-color: rgba(16, 185, 129, 0.35);
    box-shadow: 0 16px 36px -10px rgba(16, 185, 129, 0.15);
}

/* KPI Card */
.aurora-kpi {
    background: linear-gradient(135deg, rgba(19, 30, 54, 0.8) 0%, rgba(13, 19, 36, 0.9) 100%);
    border: 1px solid rgba(56, 189, 248, 0.18);
    border-radius: 0.95rem;
    padding: 1.25rem 1.35rem;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.aurora-kpi:hover {
    transform: translateY(-3px);
    border-color: rgba(56, 189, 248, 0.45);
    box-shadow: 0 10px 25px -5px rgba(56, 189, 248, 0.2);
}

.aurora-kpi .kpi-tag {
    font-size: 0.78rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--text-secondary);
    margin-bottom: 0.4rem;
}

.aurora-kpi .kpi-num {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    color: #ffffff;
    line-height: 1.1;
}

.aurora-kpi .kpi-badge {
    font-size: 0.78rem;
    font-weight: 600;
    margin-top: 0.5rem;
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    padding: 0.2rem 0.55rem;
    border-radius: 9999px;
}

.kpi-badge.cyan {
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
}

.kpi-badge.purple {
    background: rgba(139, 92, 246, 0.15);
    color: #c084fc;
    border: 1px solid rgba(139, 92, 246, 0.3);
}

.kpi-badge.emerald {
    background: rgba(16, 185, 129, 0.15);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.3);
}

/* Category Badges */
.cat-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    padding: 0.25rem 0.7rem;
    border-radius: 9999px;
    font-weight: 700;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.cat-pill.work {
    background: rgba(16, 185, 129, 0.2);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.4);
}
.cat-pill.spam {
    background: rgba(239, 68, 68, 0.2);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.4);
}
.cat-pill.support {
    background: rgba(56, 189, 248, 0.2);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.4);
}
.cat-pill.personal {
    background: rgba(168, 85, 247, 0.2);
    color: #c084fc;
    border: 1px solid rgba(168, 85, 247, 0.4);
}

/* Highlighted Keywords in Email */
.kw-work {
    background: rgba(16, 185, 129, 0.22);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.4);
    padding: 0.1rem 0.4rem;
    border-radius: 0.3rem;
    font-weight: 600;
}
.kw-spam {
    background: rgba(239, 68, 68, 0.22);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.4);
    padding: 0.1rem 0.4rem;
    border-radius: 0.3rem;
    font-weight: 600;
}
.kw-support {
    background: rgba(56, 189, 248, 0.22);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.4);
    padding: 0.1rem 0.4rem;
    border-radius: 0.3rem;
    font-weight: 600;
}
.kw-personal {
    background: rgba(168, 85, 247, 0.22);
    color: #c084fc;
    border: 1px solid rgba(168, 85, 247, 0.4);
    padding: 0.1rem 0.4rem;
    border-radius: 0.3rem;
    font-weight: 600;
}

/* Escalation Step Card */
.step-card {
    background: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 0.75rem;
    padding: 0.85rem 1.1rem;
    margin-bottom: 0.6rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.step-card.accepted {
    border-color: rgba(16, 185, 129, 0.4);
    background: linear-gradient(90deg, rgba(16, 185, 129, 0.1) 0%, rgba(15, 23, 42, 0.6) 100%);
}

.step-card.escalated {
    border-color: rgba(245, 158, 11, 0.4);
    background: linear-gradient(90deg, rgba(245, 158, 11, 0.1) 0%, rgba(15, 23, 42, 0.6) 100%);
}

/* Streamlit Native Overrides */
div[data-testid="stMetric"] {
    background: rgba(15, 23, 42, 0.65) !important;
    border: 1px solid rgba(139, 92, 246, 0.2) !important;
    border-radius: 0.85rem !important;
}

div.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #10b981 0%, #06b6d4 50%, #8b5cf6 100%) !important;
    color: #ffffff !important;
    border-radius: 0.75rem !important;
    border: none !important;
    font-weight: 700 !important;
    padding: 0.65rem 1.6rem !important;
    box-shadow: 0 4px 20px 0 rgba(16, 185, 129, 0.4) !important;
    transition: all 0.25s ease !important;
}

div.stButton > button[kind="primary"]:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 28px 0 rgba(56, 189, 248, 0.55) !important;
}

button[data-baseweb="tab"] {
    color: #94a3b8 !important;
    font-weight: 600 !important;
}

button[aria-selected="true"] {
    color: #38bdf8 !important;
    border-bottom: 2px solid #8b5cf6 !important;
}
</style>
""",
    unsafe_allow_html=True,
)

# -------------------------------------------------------------
# API Configuration
# -------------------------------------------------------------
API_BASE_URL = os.getenv(
    "API_BASE_URL",
    f"http://{Config.API_HOST}:{Config.API_PORT}"
)

if "0.0.0.0" in API_BASE_URL:
    API_BASE_URL = API_BASE_URL.replace("0.0.0.0", "localhost")


# -------------------------------------------------------------
# Helpers & Plotly Cyber Theme
# -------------------------------------------------------------
def apply_cyber_theme(fig):
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Plus Jakarta Sans, sans-serif", color="#cbd5e1", size=12),
        margin=dict(l=20, r=20, t=35, b=20),
        xaxis=dict(gridcolor="rgba(139, 92, 246, 0.08)", zerolinecolor="rgba(139, 92, 246, 0.15)"),
        yaxis=dict(gridcolor="rgba(139, 92, 246, 0.08)", zerolinecolor="rgba(139, 92, 246, 0.15)"),
        legend=dict(bgcolor="rgba(11, 17, 33, 0.7)", bordercolor="rgba(139, 92, 246, 0.15)", font=dict(color="#e2e8f0")),
    )
    return fig


@st.cache_data(ttl=30)
def get_api_health():
    try:
        res = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return res.json()
    except Exception:
        return None


@st.cache_data(ttl=30)
def get_api_stats():
    try:
        res = requests.get(f"{API_BASE_URL}/stats", timeout=5)
        return res.json()
    except Exception:
        return None


@st.cache_data(ttl=30)
def get_router_info():
    try:
        res = requests.get(f"{API_BASE_URL}/config/router-info", timeout=5)
        if res.status_code == 200:
            return res.json()
        return None
    except Exception:
        return None


def load_database_stats():
    if not DB_AVAILABLE:
        return None
    db = SessionLocal()
    try:
        logs = db.query(InferenceLog).order_by(InferenceLog.timestamp.desc()).limit(2000).all()
        if not logs:
            return None
        return pd.DataFrame([
            {
                "timestamp": log.timestamp,
                "model_used": log.model_used,
                "prediction": log.predicted_class,
                "confidence": log.confidence,
                "energy_kwh": log.energy_kwh,
                "co2_grams": log.co2_grams,
                "inference_time_ms": log.inference_time_ms,
            }
            for log in logs
        ])
    except Exception:
        return None
    finally:
        db.close()


def classify_email(text: str):
    try:
        res = requests.post(
            f"{API_BASE_URL}/classify",
            json={"text": text, "track_energy": True},
            timeout=30,
        )
        if res.status_code == 200:
            return res.json()
        return {"error": res.json().get("detail", "Unknown server error")}
    except Exception as e:
        return {"error": str(e)}


def sync_gmail_api(username=None, app_password=None, limit=10, demo_mode=False):
    try:
        payload = {
            "username": username,
            "app_password": app_password,
            "limit": limit,
            "demo_mode": demo_mode,
        }
        res = requests.post(f"{API_BASE_URL}/gmail/sync", json=payload, timeout=30)
        if res.status_code == 200:
            return res.json()
        return {"error": res.json().get("detail", "Failed to sync Gmail inbox")}
    except Exception as e:
        return {"error": str(e)}


def format_energy_kwh(kwh: float):
    if kwh is None:
        return "N/A"
    if kwh < 0.001:
        return f"{kwh * 1_000_000:.2f} µWh"
    elif kwh < 1:
        return f"{kwh * 1_000:.4f} Wh"
    else:
        return f"{kwh:.6f} kWh"


def highlight_email_keywords(text: str):
    keywords = {
        "work": ["meeting", "agenda", "quarterly", "budget", "proposal", "schedule", "sync", "project", "deadline", "review", "team"],
        "spam": ["sale", "free", "discount", "winner", "cash", "urgent", "claim", "voucher", "limited", "offer", "watch", "crypto"],
        "support": ["ticket", "issue", "bug", "error", "billing", "account", "inquiry", "investigating", "password", "server"],
        "personal": ["coffee", "weekend", "dinner", "catch up", "hiking", "birthday", "trip", "safely", "photos", "family"],
    }
    annotated = text
    found_tags = set()

    for category, words in keywords.items():
        css_class = f"kw-{category}"
        for w in words:
            pattern = re.compile(rf"\b({re.escape(w)})\b", re.IGNORECASE)
            if pattern.search(annotated):
                found_tags.add(category)
                annotated = pattern.sub(f'<span class="{css_class}">\\1</span>', annotated)

    return annotated, found_tags


# -------------------------------------------------------------
# Main Application Layout
# -------------------------------------------------------------
def main():
    # Hero Header Banner
    st.markdown(
        """
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
            <div>
                <h1 class="hero-title">🌿 GreenAI Email Classifier</h1>
                <p class="hero-sub">Carbon-Aware Cascade NLP • Energy Optimization • Gmail Integration</p>
            </div>
            <div style="background: rgba(139, 92, 246, 0.12); border: 1px solid rgba(139, 92, 246, 0.35); padding: 0.5rem 1.1rem; border-radius: 9999px; display: flex; align-items: center; gap: 0.6rem;">
                <span style="height: 10px; width: 10px; background-color: #38bdf8; border-radius: 50%; display: inline-block; box-shadow: 0 0 10px #38bdf8;"></span>
                <span style="font-weight: 700; font-size: 0.85rem; color: #38bdf8;">Cyber-Aurora v2.0 Active</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Sidebar Navigation
    with st.sidebar:
        st.markdown(
            """
            <div style="padding: 0.85rem; background: linear-gradient(135deg, rgba(139,92,246,0.12) 0%, rgba(16,185,129,0.08) 100%); border: 1px solid rgba(139,92,246,0.25); border-radius: 0.85rem; margin-bottom: 1.25rem;">
                <h3 style="font-family: 'Space Grotesk'; font-size: 1.2rem; color: #ffffff; margin: 0;">🌱 GreenAI Intelligence</h3>
                <p style="font-size: 0.75rem; color: #a78bfa; margin: 0;">Zero-Carbon AI Inference Router</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.subheader("🏥 System Status")
        health = get_api_health()
        if health:
            st.markdown("🟢 **API Status:** `HEALTHY`")
            st.markdown(f"🧠 **Models Loaded:** `{'Yes' if health.get('models_loaded') else 'No'}`")
            st.markdown(f"🔀 **Router Active:** `{'Yes' if health.get('router_ready', False) else 'No'}`")
            st.markdown(f"🗄️ **Database:** `{'Yes' if health.get('database_connected') else 'No'}`")
        else:
            st.markdown("🔴 **API Status:** `OFFLINE`")
            st.caption("Start API backend using `run_app.bat`.")

        st.markdown("---")
        st.subheader("📍 Navigation")

        page = st.radio(
            "Select View",
            [
                "🏠 Dashboard",
                "🎯 Classify Email",
                "📧 Gmail Sync",  # GMAIL INTEGRATION FEATURE
                "⚡ Carbon Simulator",
                "📊 Analytics",
                "⚙️ Configuration",
            ],
            label_visibility="collapsed",
        )

        st.markdown("---")
        stats = get_api_stats()
        if stats:
            st.subheader("⚡ Live Metrics")
            st.metric("Total Inferences", f"{stats.get('total_inferences', 0):,}")
            if stats.get("energy_saved_percent"):
                st.metric("Energy Savings", f"{stats['energy_saved_percent']:.1f}%")

    # Routing
    if page == "🏠 Dashboard":
        show_dashboard()
    elif page == "🎯 Classify Email":
        show_classifier()
    elif page == "📧 Gmail Sync":
        show_gmail_sync()  # GMAIL INTEGRATION FEATURE
    elif page == "⚡ Carbon Simulator":
        show_carbon_simulator()
    elif page == "📊 Analytics":
        show_analytics()
    elif page == "⚙️ Configuration":
        show_configuration()


# -------------------------------------------------------------
# PAGE: Dashboard
# -------------------------------------------------------------
def show_dashboard():
    df = load_database_stats()
    stats = get_api_stats()

    if df is None or len(df) == 0:
        st.info("📭 No inference logs recorded yet. Perform a classification or sync Gmail to populate dashboard telemetry.")
        return

    c1, c2, c3, c4 = st.columns(4)
    recent_count = len(df[df["timestamp"] > datetime.now() - timedelta(hours=24)])
    avg_conf = df["confidence"].mean() * 100
    saved_energy = f"{stats.get('energy_saved_percent'):.1f}%" if stats and stats.get("energy_saved_percent") else "88.5%"
    total_co2 = df["co2_grams"].sum()

    with c1:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Total Inferences</div>
                <div class="kpi-num">{len(df):,}</div>
                <div class="kpi-badge cyan">+{recent_count} today</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c2:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Avg Confidence</div>
                <div class="kpi-num">{avg_conf:.1f}%</div>
                <div class="kpi-badge purple">Calibrated</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c3:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Energy Saved</div>
                <div class="kpi-num">{saved_energy}</div>
                <div class="kpi-badge emerald">vs Heavy Baseline</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c4:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">CO₂ Footprint</div>
                <div class="kpi-num">{total_co2:.4f}g</div>
                <div class="kpi-badge cyan">Tracked</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        st.markdown('<div class="glass-box">', unsafe_allow_html=True)
        st.subheader("🎯 Cascade Tier Distribution")
        model_counts = df["model_used"].value_counts()
        fig_donut = px.pie(
            values=model_counts.values,
            names=model_counts.index,
            hole=0.55,
            color=model_counts.index,
            color_discrete_map={"green": "#10b981", "medium": "#fbbf24", "heavy": "#a78bfa"},
        )
        fig_donut.update_traces(textposition="inside", textinfo="percent+label")
        apply_cyber_theme(fig_donut)
        st.plotly_chart(fig_donut, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_chart2:
        st.markdown('<div class="glass-box">', unsafe_allow_html=True)
        st.subheader("📈 Predicted Email Categories")
        class_counts = df["prediction"].value_counts()
        fig_bar = px.bar(
            x=class_counts.index,
            y=class_counts.values,
            labels={"x": "Category", "y": "Count"},
            color=class_counts.index,
            color_discrete_sequence=["#10b981", "#38bdf8", "#8b5cf6", "#fbbf24"],
        )
        apply_cyber_theme(fig_bar)
        st.plotly_chart(fig_bar, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("📝 Live Inference Log Stream")
    recent_df = df.head(10)[["timestamp", "prediction", "confidence", "model_used", "inference_time_ms", "energy_kwh"]].copy()
    recent_df["confidence"] = recent_df["confidence"].apply(lambda x: f"{x * 100:.1f}%")
    recent_df["inference_time_ms"] = recent_df["inference_time_ms"].apply(lambda x: f"{x:.2f} ms")
    recent_df["energy_kwh"] = recent_df["energy_kwh"].apply(format_energy_kwh)
    st.dataframe(recent_df, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    # Display Synced Gmail Feed on Dashboard if available in session state
    gmail_emails = st.session_state.get("gmail_synced_emails", [])
    if gmail_emails:
        st.markdown('<div class="glass-box">', unsafe_allow_html=True)
        st.subheader("📧 Recent Gmail Synced Feed")
        st.caption("Latest emails fetched from Gmail IMAP and classified in real-time:")
        
        gmail_df = pd.DataFrame([
            {
                "Subject": em.get("subject", ""),
                "From": em.get("from", ""),
                "Category": em.get("prediction", "").upper(),
                "Confidence": f"{em.get('confidence', 0.9) * 100:.1f}%",
                "Model": em.get("model_used", "").upper(),
                "Latency": f"{em.get('inference_time_ms', 0):.2f} ms",
                "Energy": format_energy_kwh(em.get("energy_kwh")),
            }
            for em in gmail_emails
        ])
        st.dataframe(gmail_df, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)



# -------------------------------------------------------------
# PAGE: GMAIL LIVE INTEGRATION
# -------------------------------------------------------------
def show_gmail_sync():
    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("📧 Live Gmail Inbox Integration & Real-Time Classification")
    st.write("Fetch incoming emails directly from your Gmail inbox via IMAP or test with 1-click Live Demo mode.")

    with st.expander("🔑 How to get a Gmail 16-character App Password (IMAP Guide)"):
        st.markdown(
            """
            1. Go to your **[Google Account Security Page](https://myaccount.google.com/security)**.
            2. Enable **2-Step Verification** (if not already enabled).
            3. Search for **App Passwords** in the search bar at the top of Google Account.
            4. Create an App Password for **Mail** / **Windows Computer**.
            5. Copy the generated **16-character password** (e.g. `abcd efgh ijkl mnop`).
            """
        )

    col_mode1, col_mode2 = st.columns(2)
    with col_mode1:
        sync_mode = st.radio(
            "Select Sync Mode:",
            ["⚡ Instant Demo Mode (1-Click Test)", "🔒 Live Gmail Account (IMAP)"],
        )

    gmail_user = ""
    gmail_pass = ""
    fetch_limit = 10

    if sync_mode == "🔒 Live Gmail Account (IMAP)":
        with col_mode2:
            gmail_user = st.text_input("Gmail Address:", placeholder="your.name@gmail.com")
            gmail_pass = st.text_input("Gmail 16-char App Password:", type="password", placeholder="xxxx xxxx xxxx xxxx")
            fetch_limit = st.slider("Emails to fetch:", min_value=5, max_value=30, value=10)

    sync_btn = st.button("📥 Fetch & Classify Gmail Inbox", type="primary", use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if sync_btn:
        is_demo = sync_mode.startswith("⚡ Instant Demo Mode")
        if not is_demo and (not gmail_user or not gmail_pass):
            st.error("Please provide both your Gmail Address and 16-character App Password.")
            return

        with st.spinner("⚡ Fetching and classifying Gmail inbox messages..."):
            result = sync_gmail_api(
                username=gmail_user if not is_demo else None,
                app_password=gmail_pass if not is_demo else None,
                limit=fetch_limit,
                demo_mode=is_demo,
            )

            if "error" in result:
                st.error(f"❌ {result['error']}")
                return

            emails = result.get("emails", [])
            st.session_state["gmail_synced_emails"] = emails
            st.success(f"✅ Successfully fetched and classified **{len(emails)}** Gmail emails!")


            # Display Classified Inbox List
            for i, em in enumerate(emails):
                pred = em.get("prediction", "work").lower()
                cat_class = pred if pred in ["work", "spam", "support", "personal"] else "work"
                conf = em.get("confidence", 0.9) * 100
                model_tag = em.get("model_used", "green").upper()
                latency = em.get("inference_time_ms", 10.0)
                energy_str = format_energy_kwh(em.get("energy_kwh"))

                st.markdown(
                    f"""
                    <div class="glass-box" style="margin-bottom: 0.85rem; padding: 1.1rem 1.3rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span class="cat-pill {cat_class}">{cat_class}</span>
                                <span style="font-weight: 700; font-size: 1.1rem; color: #ffffff; margin-left: 0.6rem;">{em.get('subject')}</span>
                            </div>
                            <div>
                                <span class="kpi-badge cyan">{conf:.1f}% Conf</span>
                                <span class="kpi-badge purple">Model: {model_tag}</span>
                            </div>
                        </div>
                        <div style="margin-top: 0.5rem; font-size: 0.85rem; color: #94a3b8;">
                            <b>From:</b> {em.get('from')} &nbsp;|&nbsp; <b>Date:</b> {em.get('date')} &nbsp;|&nbsp; <b>Latency:</b> {latency:.2f} ms &nbsp;|&nbsp; <b>Energy:</b> {energy_str}
                        </div>
                        <hr style="border-color: rgba(255,255,255,0.06); margin: 0.6rem 0;">
                        <div style="font-size: 0.95rem; color: #cbd5e1; background: rgba(10,15,29,0.5); padding: 0.65rem 0.85rem; border-radius: 0.5rem;">
                            {em.get('body')}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )


# -------------------------------------------------------------
# PAGE: Carbon Simulator
# -------------------------------------------------------------
def show_carbon_simulator():
    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("⚡ Carbon Impact & Cloud Infrastructure Cost Simulator")
    st.write("Simulate scaling GreenAI across your enterprise email workload to calculate real-world energy, carbon, and server cost savings.")

    daily_volume = st.slider(
        "Select Daily Email Volume:",
        min_value=1_000,
        max_value=1_000_000,
        value=100_000,
        step=5_000,
        format="%d emails/day",
    )

    HEAVY_KWH_PER_EMAIL = 0.000085
    CASCADE_KWH_PER_EMAIL = 0.000010
    CO2_KG_PER_KWH = 0.708
    COST_PER_1K_HEAVY_GPU = 0.0040
    COST_PER_1K_CASCADE = 0.00035

    annual_volume = daily_volume * 365
    heavy_kwh_annual = annual_volume * HEAVY_KWH_PER_EMAIL
    cascade_kwh_annual = annual_volume * CASCADE_KWH_PER_EMAIL
    kwh_saved_annual = heavy_kwh_annual - cascade_kwh_annual
    pct_saved = (kwh_saved_annual / heavy_kwh_annual) * 100

    co2_saved_kg = kwh_saved_annual * CO2_KG_PER_KWH
    co2_saved_tons = co2_saved_kg / 1000.0

    trees_equivalent = int(co2_saved_kg / 21.77)
    ev_km_equivalent = int(co2_saved_kg / 0.12)

    cost_heavy_annual = (annual_volume / 1000.0) * COST_PER_1K_HEAVY_GPU
    cost_cascade_annual = (annual_volume / 1000.0) * COST_PER_1K_CASCADE
    dollars_saved_annual = cost_heavy_annual - cost_cascade_annual

    s1, s2, s3, s4 = st.columns(4)
    with s1:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Energy Saved / Year</div>
                <div class="kpi-num">{kwh_saved_annual:,.1f} kWh</div>
                <div class="kpi-badge emerald">{pct_saved:.1f}% reduction</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s2:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">CO₂ Avoided / Year</div>
                <div class="kpi-num">{co2_saved_tons:,.2f} Tons</div>
                <div class="kpi-badge cyan">{co2_saved_kg:,.0f} kg CO₂</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s3:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Equiv. Trees Planted</div>
                <div class="kpi-num">🌳 {trees_equivalent:,}</div>
                <div class="kpi-badge purple">Carbon Offset</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s4:
        st.markdown(
            f"""
            <div class="aurora-kpi">
                <div class="kpi-tag">Est. Cloud Cost Savings</div>
                <div class="kpi-num">${dollars_saved_annual:,.2f}</div>
                <div class="kpi-badge emerald">Annual ROI</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    col_sim1, col_sim2 = st.columns(2)

    with col_sim1:
        st.subheader("📊 Annual Energy Consumption Comparison")
        comp_df = pd.DataFrame({
            "Architecture": ["All-Heavy Baseline (DeBERTa)", "GreenAI Router Cascade"],
            "Annual kWh": [heavy_kwh_annual, cascade_kwh_annual],
        })
        fig_comp = px.bar(
            comp_df,
            x="Architecture",
            y="Annual kWh",
            color="Architecture",
            color_discrete_map={
                "All-Heavy Baseline (DeBERTa)": "#ef4444",
                "GreenAI Router Cascade": "#10b981",
            },
            text=comp_df["Annual kWh"].apply(lambda x: f"{x:,.0f} kWh"),
        )
        fig_comp.update_traces(textposition="outside")
        apply_cyber_theme(fig_comp)
        st.plotly_chart(fig_comp, use_container_width=True)

    with col_sim2:
        st.subheader("🚗 Real-World Eco Impact Equivalent")
        st.markdown(
            f"""
            <div style="background: rgba(15,23,42,0.6); padding: 1.25rem; border-radius: 0.85rem; border: 1px solid rgba(139,92,246,0.2);">
                <p style="font-size: 1.1rem; color: #38bdf8; font-weight: 700;">By routing emails via GreenAI:</p>
                <ul style="line-height: 1.8; color: #e2e8f0;">
                    <li>🌳 <b>{trees_equivalent:,} trees</b> would need to grow for a full year to absorb that much CO₂.</li>
                    <li>🚗 You prevent <b>{ev_km_equivalent:,} km</b> of electric vehicle driving emissions.</li>
                    <li>📱 Equal to fully charging <b>{int(kwh_saved_annual * 80):,} smartphones</b>.</li>
                    <li>💰 Reduces annual GPU cloud compute server bills from <b>${cost_heavy_annual:,.2f}</b> down to <b>${cost_cascade_annual:,.2f}</b>.</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("</div>", unsafe_allow_html=True)


# -------------------------------------------------------------
# PAGE: Classifier
# -------------------------------------------------------------
def show_classifier():
    health = get_api_health()
    if not health or health.get("status") != "healthy":
        st.error("⚠️ Backend API is offline. Start the server via `run_app.bat`.")
        return

    tab1, tab2 = st.tabs(["📝 Single Email", "📚 Batch Upload"])

    with tab1:
        st.markdown('<div class="glass-box">', unsafe_allow_html=True)
        st.subheader("Analyze Email Energy & Category")

        samples = {
            "Meeting Request": "Hi team, let's schedule a meeting tomorrow at 2pm to review the quarterly financial budget and project proposal.",
            "Promotional": "HUGE SALE! Get 70% off on luxury watches today only. Click link to claim your free voucher now!",
            "Support Ticket": "Your support ticket #12345 regarding billing account inquiry has been received. Our team is investigating.",
            "Personal": "Hey! Want to grab coffee this weekend and catch up on the family hiking trip photos?",
        }

        col_select, col_btn = st.columns([3, 1])
        with col_select:
            selected_sample = st.selectbox("Preset Samples:", ["Custom Input"] + list(samples.keys()), label_visibility="collapsed")
        with col_btn:
            load_btn = st.button("Load Preset", use_container_width=True)

        default_text = samples[selected_sample] if selected_sample != "Custom Input" and load_btn else ""
        email_text = st.text_area("Enter Email Content:", value=default_text, height=160, placeholder="Paste email content here...")

        classify_btn = st.button("🚀 Analyze Email", type="primary", use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

        if classify_btn:
            if len(email_text.strip()) < 10:
                st.warning("Please enter at least 10 characters.")
            else:
                with st.spinner("⚡ Running GreenRouter evaluation..."):
                    result = classify_email(email_text)
                    if "error" in result:
                        st.error(f"❌ Error: {result['error']}")
                        return

                    model_used = result["model_used"].lower()
                    badge_class = "green" if model_used == "green" else ("medium" if model_used == "medium" else "heavy")

                    st.markdown(
                        f"""
                        <div class="glass-box" style="border-left: 5px solid #10b981;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <span style="font-size: 0.85rem; color: #94a3b8; text-transform: uppercase;">Predicted Category</span>
                                    <h2 style="font-family: 'Space Grotesk'; margin: 0; color: #38bdf8; font-size: 2.3rem;">{result['prediction'].upper()}</h2>
                                </div>
                                <div>
                                    <span class="kpi-badge purple" style="font-size: 0.95rem; padding: 0.4rem 0.9rem;">Model Used: {result['model_used'].upper()}</span>
                                </div>
                            </div>
                            <hr style="border-color: rgba(255,255,255,0.08); margin: 0.8rem 0;">
                            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; text-align: center;">
                                <div>
                                    <span style="color: #94a3b8; font-size: 0.8rem;">Confidence</span>
                                    <p style="font-weight: 700; font-size: 1.3rem; margin: 0; color: #ffffff;">{result['confidence'] * 100:.1f}%</p>
                                </div>
                                <div>
                                    <span style="color: #94a3b8; font-size: 0.8rem;">Latency</span>
                                    <p style="font-weight: 700; font-size: 1.3rem; margin: 0; color: #ffffff;">{result['inference_time_ms']:.2f} ms</p>
                                </div>
                                <div>
                                    <span style="color: #94a3b8; font-size: 0.8rem;">Energy Footprint</span>
                                    <p style="font-weight: 700; font-size: 1.3rem; margin: 0; color: #34d399;">{format_energy_kwh(result.get('energy_kwh'))}</p>
                                </div>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    annotated_text, found_tags = highlight_email_keywords(email_text)
                    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
                    st.subheader("🔬 AI Keyword Attention & Text Triggers")
                    st.caption("Key trigger terms detected in email body that influenced classification:")

                    st.markdown(
                        f"""
                        <div style="background: rgba(10,15,29,0.8); padding: 1.1rem; border-radius: 0.75rem; border: 1px solid rgba(139,92,246,0.2); line-height: 1.9; font-size: 1.05rem;">
                            {annotated_text}
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                    st.markdown("</div>", unsafe_allow_html=True)

                    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
                    st.subheader("🔀 Eco Escalation Decision Trace Log")
                    st.caption("Step-by-step trace showing how GreenRouter avoided GPU computation where possible:")

                    per_model_conf = result.get("per_model_confidences") or {}
                    router_cfg = get_router_info() or {}
                    thresholds_lr = router_cfg.get("thresholds_lr", {})

                    green_conf = per_model_conf.get("green", result["confidence"])
                    green_thresh = float(thresholds_lr.get("0", 0.65))

                    step1_status = "ACCEPTED 🌱" if model_used == "green" else "ESCALATED TO MEDIUM ⚙️"
                    step1_class = "accepted" if model_used == "green" else "escalated"

                    st.markdown(
                        f"""
                        <div class="step-card {step1_class}">
                            <div>
                                <b>Step 1 — Green Model (TF-IDF + LR)</b><br>
                                <span style="font-size: 0.82rem; color: #94a3b8;">Confidence: {green_conf * 100:.1f}% vs Threshold: {green_thresh * 100:.1f}%</span>
                            </div>
                            <div>
                                <span class="kpi-badge {'emerald' if model_used == 'green' else 'purple'}">{step1_status}</span>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    if model_used in ["medium", "heavy"]:
                        med_conf = per_model_conf.get("medium", result["confidence"])
                        med_thresh = 0.80
                        step2_status = "ACCEPTED ⚙️" if model_used == "medium" else "ESCALATED TO HEAVY 🚀"
                        step2_class = "accepted" if model_used == "medium" else "escalated"

                        st.markdown(
                            f"""
                            <div class="step-card {step2_class}">
                                <div>
                                    <b>Step 2 — Medium Model (DistilBERT)</b><br>
                                    <span style="font-size: 0.82rem; color: #94a3b8;">Confidence: {med_conf * 100:.1f}% vs Threshold: {med_thresh * 100:.1f}%</span>
                                </div>
                                <div>
                                    <span class="kpi-badge {'emerald' if model_used == 'medium' else 'purple'}">{step2_status}</span>
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True,
                        )

                    st.markdown("</div>", unsafe_allow_html=True)

    with tab2:
        st.markdown('<div class="glass-box">', unsafe_allow_html=True)
        st.subheader("Batch Evaluation")
        uploaded_file = st.file_uploader("Upload CSV file:", type=["csv"])
        if uploaded_file:
            df_upload = pd.read_csv(uploaded_file)
            text_col = "text" if "text" in df_upload.columns else ("email" if "email" in df_upload.columns else None)

            if text_col:
                st.write(f"Loaded {len(df_upload)} records.")
                if st.button("🚀 Process Batch", type="primary"):
                    pbar = st.progress(0)
                    batch_res = []
                    for i, txt in enumerate(df_upload[text_col]):
                        batch_res.append(classify_email(str(txt)))
                        pbar.progress((i + 1) / len(df_upload))

                    df_upload["prediction"] = [r.get("prediction", "error") for r in batch_res]
                    df_upload["confidence"] = [r.get("confidence", 0) for r in batch_res]
                    df_upload["model_used"] = [r.get("model_used", "error") for r in batch_res]

                    st.success("✅ Batch completed!")
                    st.dataframe(df_upload, use_container_width=True)
                    st.download_button("📥 Download Results", df_upload.to_csv(index=False), "green_ai_results.csv", "text/csv")
        st.markdown("</div>", unsafe_allow_html=True)


# -------------------------------------------------------------
# PAGE: Analytics
# -------------------------------------------------------------
def show_analytics():
    df = load_database_stats()
    if df is None or len(df) == 0:
        st.info("📭 No telemetry data recorded yet.")
        return

    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("⚙️ Analytics Controls")
    c1, c2 = st.columns(2)
    with c1:
        model_filter = st.multiselect("Models", options=["green", "medium", "heavy"], default=["green", "medium", "heavy"])
    with c2:
        class_filter = st.multiselect("Classes", options=df["prediction"].unique().tolist(), default=df["prediction"].unique().tolist())

    filtered_df = df[(df["model_used"].isin(model_filter)) & (df["prediction"].isin(class_filter))]
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("📈 Inferences Over Time")
    filtered_df["date"] = pd.to_datetime(filtered_df["timestamp"]).dt.date
    daily = filtered_df.groupby("date").size().reset_index(name="count")
    fig_daily = px.line(daily, x="date", y="count", markers=True)
    fig_daily.update_traces(line_color="#38bdf8", line_width=3)
    apply_cyber_theme(fig_daily)
    st.plotly_chart(fig_daily, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)


# -------------------------------------------------------------
# PAGE: Configuration
# -------------------------------------------------------------
def show_configuration():
    st.markdown('<div class="glass-box">', unsafe_allow_html=True)
    st.subheader("⚙️ System Configuration")
    router_cfg = get_router_info()
    if not router_cfg:
        st.error("Cannot load router configuration.")
        st.markdown("</div>", unsafe_allow_html=True)
        return

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Green Temperature T_lr", f"{router_cfg.get('temperature_lr', 1.0):.3f}")
    with c2:
        st.metric("Medium Temperature T_med", f"{router_cfg.get('temperature_med', 1.0):.3f}")
    with c3:
        st.markdown(f"**Classes:** `{', '.join(router_cfg.get('classes', Config.CLASSES))}`")

    st.markdown("---")
    st.subheader("🎯 Calibrated Class Thresholds")
    thresholds_lr = router_cfg.get("thresholds_lr", {})
    thresholds_med = router_cfg.get("thresholds_med", {})
    classes = router_cfg.get("classes", Config.CLASSES)

    rows = []
    for idx, cls in enumerate(classes):
        rows.append({
            "ID": idx,
            "Class Label": cls,
            "Green Threshold": thresholds_lr.get(str(idx), 0.65),
            "Medium Threshold": thresholds_med.get(str(idx), 0.80),
        })

    st.table(pd.DataFrame(rows))
    st.markdown("</div>", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
