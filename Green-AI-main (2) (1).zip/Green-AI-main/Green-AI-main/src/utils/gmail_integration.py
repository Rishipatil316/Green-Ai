# File: src/utils/gmail_integration.py
# Gmail IMAP Fetcher & Live Demo Generator for GreenAI Email Classifier

import sys
import imaplib
import email
from email.header import decode_header
from typing import List, Dict, Any, Optional
import datetime

# Fix Windows console encoding if needed
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


class GmailFetcher:
    """Handles secure IMAP fetching of Gmail inbox messages."""

    IMAP_SERVER = "imap.gmail.com"
    IMAP_PORT = 993

    @staticmethod
    def _clean_header_str(header_val) -> str:
        """Decode email header string safely."""
        if not header_val:
            return ""
        decoded_list = decode_header(header_val)
        result = []
        for content, encoding in decoded_list:
            if isinstance(content, bytes):
                try:
                    result.append(content.decode(encoding or "utf-8", errors="replace"))
                except Exception:
                    result.append(content.decode("latin-1", errors="replace"))
            else:
                result.append(str(content))
        return " ".join(result)

    @classmethod
    def fetch_gmail_emails(
        cls,
        username: str,
        app_password: str,
        folder: str = "INBOX",
        limit: int = 10,
    ) -> Dict[str, Any]:
        """
        Connect to Gmail via IMAP over SSL and fetch recent emails.

        Args:
            username: Gmail address (e.g. user@gmail.com)
            app_password: Gmail 16-character App Password
            folder: Mailbox folder (default: 'INBOX')
            limit: Maximum number of emails to fetch

        Returns:
            Dict containing status, email list, or error description.
        """
        if not username or not app_password:
            return {"status": "error", "error": "Gmail address and App Password are required."}

        try:
            # Establish SSL IMAP Connection
            mail = imaplib.IMAP4_SSL(cls.IMAP_SERVER, cls.IMAP_PORT)
            mail.login(username, app_password)
            mail.select(folder)

            # Search for messages
            status, messages = mail.search(None, "ALL")
            if status != "OK":
                return {"status": "error", "error": "Failed to search mailbox."}

            mail_ids = messages[0].split()
            if not mail_ids:
                return {"status": "success", "emails": [], "count": 0}

            # Get latest 'limit' email IDs
            latest_ids = mail_ids[-limit:]
            latest_ids.reverse()

            fetched_emails = []

            for m_id in latest_ids:
                res_status, msg_data = mail.fetch(m_id, "(RFC822)")
                if res_status != "OK":
                    continue

                for response_part in msg_data:
                    if isinstance(response_part, tuple):
                        msg = email.message_from_bytes(response_part[1])
                        subject = cls._clean_header_str(msg.get("Subject"))
                        from_addr = cls._clean_header_str(msg.get("From"))
                        date_str = cls._clean_header_str(msg.get("Date"))

                        # Extract text body
                        body = ""
                        if msg.is_multipart():
                            for part in msg.walk():
                                content_type = part.get_content_type()
                                content_disposition = str(part.get("Content-Disposition"))
                                if content_type == "text/plain" and "attachment" not in content_disposition:
                                    payload = part.get_payload(decode=True)
                                    if payload:
                                        body = payload.decode("utf-8", errors="replace")
                                        break
                        else:
                            payload = msg.get_payload(decode=True)
                            if payload:
                                body = payload.decode("utf-8", errors="replace")

                        if not body:
                            body = subject  # Fallback to subject if body empty

                        fetched_emails.append(
                            {
                                "id": m_id.decode("utf-8", errors="replace"),
                                "subject": subject or "(No Subject)",
                                "from": from_addr or "Unknown Sender",
                                "date": date_str or datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S"),
                                "body": body.strip(),
                            }
                        )

            mail.logout()
            return {"status": "success", "emails": fetched_emails, "count": len(fetched_emails)}

        except imaplib.IMAP4.error as e:
            return {"status": "error", "error": f"Gmail Authentication Error: Check your Gmail address and 16-character App Password. ({e})"}
        except Exception as e:
            return {"status": "error", "error": f"Failed to connect to Gmail IMAP: {e}"}

    @staticmethod
    def get_demo_gmail_inbox() -> List[Dict[str, Any]]:
        """Generates realistic sample Gmail inbox emails for instant 1-click testing."""
        now = datetime.datetime.now()
        return [
            {
                "id": "1001",
                "subject": "Q3 Engineering Roadmap & Team Sprint Sync",
                "from": "Alex Rivera <alex.rivera@techcorp.io>",
                "date": (now - datetime.timedelta(minutes=14)).strftime("%a, %d %b %Y %H:%M:%S"),
                "body": "Hi team, let's schedule a sync meeting tomorrow at 2pm to review the quarterly roadmap and project budget proposals. Please update your Jira tickets.",
            },
            {
                "id": "1002",
                "subject": "URGENT: Exclusive 80% Off Flash Sale — Claim Voucher Now!",
                "from": "Deals Alert <promotions@discountflash.com>",
                "date": (now - datetime.timedelta(minutes=45)).strftime("%a, %d %b %Y %H:%M:%S"),
                "body": "CONGRATULATIONS! You have been selected to win a free gift card. Click link now to claim your 80% discount voucher before stock runs out!",
            },
            {
                "id": "1003",
                "subject": "Support Ticket #48291: Server Database Latency Issue",
                "from": "DevOps Desk <support@cloudops.org>",
                "date": (now - datetime.timedelta(hours=2)).strftime("%a, %d %b %Y %H:%M:%S"),
                "body": "Your support ticket #48291 regarding billing portal latency has been updated. Our engineering team is currently investigating server logs.",
            },
            {
                "id": "1004",
                "subject": "Coffee this weekend & photos from the trip!",
                "from": "Sarah Jenkins <sarah.j@gmail.com>",
                "date": (now - datetime.timedelta(hours=5)).strftime("%a, %d %b %Y %H:%M:%S"),
                "body": "Hey! Want to grab coffee this weekend and catch up on the family hiking trip photos? Let me know what time works best for you.",
            },
            {
                "id": "1005",
                "subject": "Action Required: Verify Security Settings for Google Workspace",
                "from": "Google Security Desk <no-reply@accounts.google.com>",
                "date": (now - datetime.timedelta(hours=8)).strftime("%a, %d %b %Y %H:%M:%S"),
                "body": "A new sign-in was detected on your account. Please review your active sessions and update two-step verification settings if necessary.",
            },
        ]
