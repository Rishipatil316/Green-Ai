#!/usr/bin/env python3
# File: scripts/prepare_dataset.py
# Dataset preparation script with synthetic data generation support

import sys
import argparse
from pathlib import Path
import pandas as pd
import numpy as np

# Project root
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
sys.path.append(str(PROJECT_ROOT))

# Fix Windows console encoding if needed
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from src.config import Config
from src.utils.preprocessing import EmailPreprocessor, split_dataset


def create_synthetic_email_dataset(samples_per_class: int = 250) -> pd.DataFrame:
    """Generate a realistic synthetic email dataset across all classes."""
    np.random.seed(Config.RANDOM_STATE)
    preprocessor = EmailPreprocessor()

    templates = {
        "work": [
            "Hi team, let's schedule a sync meeting tomorrow at {time} to review the quarterly roadmap.",
            "Please review the attached project proposal for the new enterprise client.",
            "The updated budget spreadsheet has been uploaded to the shared folder.",
            "Reminder: Engineering team sprint planning starts at {time} in Conference Room B.",
            "Could you send me the latest progress report on the system migration task?",
        ],
        "spam": [
            "CONGRATULATIONS! You have been selected to win a free {prize}. Click link to claim now!",
            "URGENT: Your account requires immediate verification. Sign in here to unlock.",
            "Exclusive offer! Save 90% on all luxury watches and electronics today only.",
            "Make $5000 a week working from home! No experience required, start immediately.",
            "Claim your $1000 Amazon gift card voucher by completing this 2-minute survey.",
        ],
        "support": [
            "Your support ticket #{ticket} regarding password reset has been updated.",
            "Customer Support: We have received your inquiry about order #{order} and are looking into it.",
            "Issue resolved: The server connectivity bug reported in ticket #{ticket} is now fixed.",
            "Hello, I am having trouble accessing my billing dashboard. Please assist.",
            "Technical Support Update: Scheduled maintenance will occur tonight at midnight.",
        ],
        "personal": [
            "Hey! Are you free this weekend to grab coffee and catch up?",
            "Thanks for dinner yesterday, had a great time seeing everyone!",
            "Happy birthday! Hope you have an awesome day celebrating.",
            "Let me know when you get home safely after the trip.",
            "Hey, sending over the photos from our weekend hiking trip!",
        ],
    }

    data = []
    prizes = ["iPhone 15", "Tesla Model 3", "Walmart Gift Card", "Crypto Token"]

    for label, t_list in templates.items():
        for i in range(samples_per_class):
            template = np.random.choice(t_list)
            text = template.format(
                time=f"{np.random.randint(9, 17)}:00",
                prize=np.random.choice(prizes),
                ticket=np.random.randint(10000, 99999),
                order=np.random.randint(500000, 999999),
            )
            processed = preprocessor.clean_text(text)
            data.append({"text": text, "processed_text": processed, "label": label})

    df = pd.DataFrame(data).sample(frac=1, random_state=42).reset_index(drop=True)
    return df


def main():
    parser = argparse.ArgumentParser(description="Prepare GreenAI Email Classifier Dataset")
    parser.add_argument("--synthetic", action="store_true", help="Generate synthetic dataset")
    args = parser.parse_args()

    print("==========================================================")
    print("🌿 GreenAI Dataset Preparation")
    print("==========================================================")

    Config.PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

    if args.synthetic or not list(Config.RAW_DATA_DIR.glob("*.csv")):
        print("⚙️ Generating synthetic dataset (1000 total samples)...")
        df = create_synthetic_email_dataset(samples_per_class=250)
    else:
        raw_csvs = list(Config.RAW_DATA_DIR.glob("*.csv"))
        print(f"📄 Loading raw dataset from: {raw_csvs[0]}")
        df = pd.read_csv(raw_csvs[0])
        preprocessor = EmailPreprocessor()
        text_col = "text" if "text" in df.columns else df.columns[0]
        df["processed_text"] = df[text_col].apply(preprocessor.clean_text)

    train_df, val_df, test_df = split_dataset(df)

    train_path = Config.PROCESSED_DATA_DIR / "train.csv"
    val_path = Config.PROCESSED_DATA_DIR / "val.csv"
    test_path = Config.PROCESSED_DATA_DIR / "test.csv"

    train_df.to_csv(train_path, index=False)
    val_df.to_csv(val_path, index=False)
    test_df.to_csv(test_path, index=False)

    print(f"✅ Saved splits to: {Config.PROCESSED_DATA_DIR}")
    print(f"   - Train: {len(train_df)} samples")
    print(f"   - Val:   {len(val_df)} samples")
    print(f"   - Test:  {len(test_df)} samples")


if __name__ == "__main__":
    main()
