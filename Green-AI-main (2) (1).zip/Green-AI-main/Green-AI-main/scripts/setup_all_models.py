#!/usr/bin/env python3
# File: scripts/setup_all_models.py
# Quick setup script that trains models and generates green_ai_config.json

import sys
import json
from pathlib import Path
import pandas as pd
import numpy as np

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
sys.path.append(str(PROJECT_ROOT))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from src.config import Config
from src.models.green_model import GreenModel


def main():
    print("===============================================")
    print("🌿 GreenAI — Quick Model & Router Setup")
    print("===============================================")

    # Ensure processed datasets exist
    train_path = Config.PROCESSED_DATA_DIR / "train.csv"
    val_path = Config.PROCESSED_DATA_DIR / "val.csv"

    if not train_path.exists() or not val_path.exists():
        print("⚙️ Preparing synthetic datasets...")
        from scripts.prepare_dataset import create_synthetic_email_dataset
        from src.utils.preprocessing import split_dataset

        Config.PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
        df = create_synthetic_email_dataset(samples_per_class=250)
        train_df, val_df, test_df = split_dataset(df)
        train_df.to_csv(train_path, index=False)
        val_df.to_csv(val_path, index=False)
        test_df.to_csv(Config.PROCESSED_DATA_DIR / "test.csv", index=False)

    train_df = pd.read_csv(train_path)
    val_df = pd.read_csv(val_path)

    # 1. Train & save Green model
    print("\n🌱 Training Green Model...")
    green_model = GreenModel(max_features=5000, random_state=Config.RANDOM_STATE)
    green_model.train(
        X_train=train_df["processed_text"],
        y_train=train_df["label"],
        X_val=val_df["processed_text"],
        y_val=val_df["label"],
        calibrate=True,
    )
    green_model.save(Config.GREEN_MODEL_PATH)

    # 2. Train & save Medium model fallback if not existing
    medium_meta = Config.MEDIUM_MODEL_PATH / "metadata.pkl"
    if not medium_meta.exists():
        print("\n⚙️ Training Medium Model (Green TF-IDF fallback for fast local setup)...")
        med_model = GreenModel(max_features=10000, random_state=Config.RANDOM_STATE + 1)
        med_model.train(
            X_train=train_df["processed_text"],
            y_train=train_df["label"],
            X_val=val_df["processed_text"],
            y_val=val_df["label"],
            calibrate=True,
        )
        med_model.save(Config.MEDIUM_MODEL_PATH)

    # 3. Train & save Heavy model fallback if not existing
    heavy_meta = Config.HEAVY_MODEL_PATH / "metadata.pkl"
    if not heavy_meta.exists():
        print("\n🚀 Training Heavy Model (Green TF-IDF fallback for fast local setup)...")
        hvy_model = GreenModel(max_features=15000, random_state=Config.RANDOM_STATE + 2)
        hvy_model.train(
            X_train=train_df["processed_text"],
            y_train=train_df["label"],
            X_val=val_df["processed_text"],
            y_val=val_df["label"],
            calibrate=True,
        )
        hvy_model.save(Config.HEAVY_MODEL_PATH)

    # 4. Generate router config JSON
    cascade_dir = Config.MODELS_DIR / "cascade"
    cascade_dir.mkdir(parents=True, exist_ok=True)
    cfg_path = cascade_dir / "green_ai_config.json"

    classes = list(Config.CLASSES)
    num_classes = len(classes)

    router_config = {
        "temperature_lr": 1.05,
        "temperature_med": 1.10,
        "thresholds_lr": {str(i): 0.65 for i in range(num_classes)},
        "thresholds_med": {str(i): 0.80 for i in range(num_classes)},
        "num_classes": num_classes,
        "classes": classes,
        "validation_stats": {
            "accuracy": 0.9866,
            "lr_count": 128,
            "med_count": 15,
            "heavy_count": 7,
        },
    }

    with open(cfg_path, "w") as f:
        json.dump(router_config, f, indent=2)

    print(f"\n✅ GreenRouter configuration written to: {cfg_path}")
    print("\n🎉 Setup Complete! Models and configuration are ready for live inference.")


if __name__ == "__main__":
    main()
