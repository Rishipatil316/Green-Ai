@echo off
title Launching GreenAI Email Classifier...
set PYTHONIOENCODING=utf-8
echo ===================================================
echo 🌿 Starting GreenAI Backend API & Streamlit Dashboard
echo ===================================================

echo Step 1: Ensuring models and datasets are prepared...
python scripts/setup_all_models.py

echo.
echo Step 2: Starting FastAPI Backend on http://localhost:8000 ...
start "GreenAI API Backend" cmd /k "set PYTHONIOENCODING=utf-8 && python -m uvicorn src.api.main:app --host 0.0.0.0 --port 8000"

timeout /t 3 >nul

echo.
echo Step 3: Starting Streamlit Dashboard on http://localhost:8501 ...
python -m streamlit run src/dashboard/app.py

pause
